package com.summitcreditunion;


//To encrypt in Java, use a java Properties object to add the property values.
import java.util.Properties;
import java.util.Set;
import java.util.Base64;
import java.util.Date;
import java.io.ByteArrayOutputStream;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.net.URLEncoder;
import java.security.Key;
import java.security.SecureRandom;




public class Aes {

  String error = null;
  Properties props;
  String encrypted_b64 = "";
 

  public String do_AESEncryption( String url,   String clientId , String requestType , 
          String payload, String base64Key)
          throws Exception {
      props = new Properties();
      props.setProperty("CLIENT_ID", clientId);
      props.setProperty("REQUEST_TYPE", requestType);
      //String timestamp = new Long(new Date().getTime()).toString();
      //props.setProperty("harland.timestamp", timestamp);
      Set<String> keys = props.stringPropertyNames();
      String parameters = "";
      for (String key : keys) {
          if(parameters == ""){
              parameters += key + "=" + props.getProperty(key);
          }else{
              parameters += "&" + key + "=" + props.getProperty(key);
          }
         
      }

      

      try {
          // Convert properties to byte array
          ByteArrayOutputStream bytes = new ByteArrayOutputStream();
          props.store(bytes, null);
          byte propsBytes[] = bytes.toByteArray();

          // convert base64 encoded key
          Key key = new SecretKeySpec(Base64.getDecoder().decode(base64Key), "AES");

          // generate random IV
          SecureRandom sr = new SecureRandom();
          byte iv[] = new byte[16];
          sr.nextBytes(iv);
          IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);

          // declare AES cipher
          Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
          // init with random IV
          cipher.init(1, key, ivParameterSpec);
          
          // encrypt payload
          byte encryptedData[] = cipher.doFinal(payload.getBytes());
          // pre-pend IV as first 16 bytes of encrypted string
          byte encryptedDataPlusIv[] = new byte[iv.length + encryptedData.length];
          String strEcodedDataPlusIv = new String(encryptedDataPlusIv);
          
          
          System.arraycopy(iv, 0, encryptedDataPlusIv, 0, iv.length);
          System.arraycopy(encryptedData, 0, encryptedDataPlusIv, iv.length, encryptedData.length);
          
          
     

          // base64 encode the encrypted byte array
		    String encrypted_b64 = Base64.getEncoder().encodeToString(encryptedDataPlusIv);
		    
		    String encrypted_b64_url = URLEncoder.encode(encrypted_b64);
          return url + "?"+ parameters + "&ENCRYPTED_DATA=" + encrypted_b64_url;
      } catch (Exception e) {
        
          throw new Exception("Error Encrypting payload in jar file.Error: "+ e.getMessage());
      }

  }
  

}
