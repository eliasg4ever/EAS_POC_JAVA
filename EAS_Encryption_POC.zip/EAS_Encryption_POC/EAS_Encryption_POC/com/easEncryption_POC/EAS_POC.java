package com.easEncryption_POC;

import java.util.Base64;

import javax.crypto.SecretKey;

public class EAS_POC {


        
    public static void main(String[] args) throws Exception{
        



    }

   

    
}
