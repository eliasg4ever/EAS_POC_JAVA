package com.summitcreditunion;

public class AesMain {
    
    public static void main(String[] args) throws Exception {
        /*
        Aes aes = new Aes();
        String url = "HTTPS://vanwebuat.harland.net/integration/security";
        String payload = "applicationName=Test,Order=10";
        String base64Key = "1S+rcCqPoeZ5GlHIW4PqVNUvq3Aqj6Hm";
        
        String clientId = "05785";
        String  requestType = "encrypted2";
        
        String encryptedData = aes.do_AESEncryption(url,clientId , requestType , payload, base64Key);
        System.out.println(encryptedData);
       */
    }
    
}